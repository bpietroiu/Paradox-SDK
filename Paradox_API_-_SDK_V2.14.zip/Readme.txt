Copyright (c) 1998-2016, Paradox Security Systems Ltd.
		All rights reserved.

**Paradox API SDK V2.14**

1. Driver: 
	Copy: Bin\ParadoxAPI.DLL	
	Copy: Bin\IPDOX.DLL
	Copy: Bin\ParadoxNetwork.DLL

2. API Integration: 
	See: Documentation\ParadoxAPI V2.14.doc

3. Paradox Video Player
	see: Bin\Paradox Video Player\ParadoxVideoPlayer.exe

4. Demo application: 
	Start: Bin\ParadoxApiDemo.exe

5. Demo Source Code: (Desktop Visual Studio 2013)
	See: ParadoxAPIClient C#\Source\ParadoxApiDemo\ParadoxApiDemo.sln



May 20, 2016
RD Software